package cn.iocoder.yudao.module.haoka.dal.mysql.superiorproductconfig;

import java.util.*;

import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.framework.common.pojo.PageParam;
import cn.iocoder.yudao.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.yudao.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.yudao.module.haoka.dal.dataobject.superiorproductconfig.SuperiorProductConfigDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 产品对接上游配置 Mapper
 *
 * @author 芋道源码
 */
@Mapper
public interface SuperiorProductConfigMapper extends BaseMapperX<SuperiorProductConfigDO> {

    default PageResult<SuperiorProductConfigDO> selectPage(PageParam reqVO, Long haokaSuperiorApiId) {
        return selectPage(reqVO, new LambdaQueryWrapperX<SuperiorProductConfigDO>()
            .eq(SuperiorProductConfigDO::getHaokaSuperiorApiId, haokaSuperiorApiId)
            .orderByDesc(SuperiorProductConfigDO::getId));
    }

    default int deleteByHaokaSuperiorApiId(Long haokaSuperiorApiId) {
        return delete(SuperiorProductConfigDO::getHaokaSuperiorApiId, haokaSuperiorApiId);
    }

}