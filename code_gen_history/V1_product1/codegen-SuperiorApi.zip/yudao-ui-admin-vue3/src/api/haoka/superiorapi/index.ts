import request from '@/config/axios'

// 上游API接口 VO
export interface SuperiorApiVO {
  id: number // ID
  name: string // 名字
  enableSelectNum: boolean // 是否有选号功能
  abnormalOrderHandleMethod: number // 异常订单处理方式
  status: number // 接口状态
  publishTime: Date // 发布日期
  apiDoc: string // API文档
  isDevConfined: boolean // 是否已配置开发
  isSkuConfined: boolean // 是否已配置产品
}

// 上游API接口 API
export const SuperiorApiApi = {
  // 查询上游API接口分页
  getSuperiorApiPage: async (params: any) => {
    return await request.get({ url: `/haoka/superior-api/page`, params })
  },

  // 查询上游API接口详情
  getSuperiorApi: async (id: number) => {
    return await request.get({ url: `/haoka/superior-api/get?id=` + id })
  },

  // 新增上游API接口
  createSuperiorApi: async (data: SuperiorApiVO) => {
    return await request.post({ url: `/haoka/superior-api/create`, data })
  },

  // 修改上游API接口
  updateSuperiorApi: async (data: SuperiorApiVO) => {
    return await request.put({ url: `/haoka/superior-api/update`, data })
  },

  // 删除上游API接口
  deleteSuperiorApi: async (id: number) => {
    return await request.delete({ url: `/haoka/superior-api/delete?id=` + id })
  },

  // 导出上游API接口 Excel
  exportSuperiorApi: async (params) => {
    return await request.download({ url: `/haoka/superior-api/export-excel`, params })
  },

// ==================== 子表（上游API接口开发配置） ====================

  // 获得上游API接口开发配置分页
  getSuperiorApiDevConfigPage: async (params) => {
    return await request.get({ url: `/haoka/superior-api/superior-api-dev-config/page`, params })
  },
  // 新增上游API接口开发配置
  createSuperiorApiDevConfig: async (data) => {
    return await request.post({ url: `/haoka/superior-api/superior-api-dev-config/create`, data })
  },

  // 修改上游API接口开发配置
  updateSuperiorApiDevConfig: async (data) => {
    return await request.put({ url: `/haoka/superior-api/superior-api-dev-config/update`, data })
  },

  // 删除上游API接口开发配置
  deleteSuperiorApiDevConfig: async (id: number) => {
    return await request.delete({ url: `/haoka/superior-api/superior-api-dev-config/delete?id=` + id })
  },

  // 获得上游API接口开发配置
  getSuperiorApiDevConfig: async (id: number) => {
    return await request.get({ url: `/haoka/superior-api/superior-api-dev-config/get?id=` + id })
  },

// ==================== 子表（上游API接口SKU要求配置） ====================

  // 获得上游API接口SKU要求配置分页
  getSuperiorApiSkuConfigPage: async (params) => {
    return await request.get({ url: `/haoka/superior-api/superior-api-sku-config/page`, params })
  },
  // 新增上游API接口SKU要求配置
  createSuperiorApiSkuConfig: async (data) => {
    return await request.post({ url: `/haoka/superior-api/superior-api-sku-config/create`, data })
  },

  // 修改上游API接口SKU要求配置
  updateSuperiorApiSkuConfig: async (data) => {
    return await request.put({ url: `/haoka/superior-api/superior-api-sku-config/update`, data })
  },

  // 删除上游API接口SKU要求配置
  deleteSuperiorApiSkuConfig: async (id: number) => {
    return await request.delete({ url: `/haoka/superior-api/superior-api-sku-config/delete?id=` + id })
  },

  // 获得上游API接口SKU要求配置
  getSuperiorApiSkuConfig: async (id: number) => {
    return await request.get({ url: `/haoka/superior-api/superior-api-sku-config/get?id=` + id })
  },

// ==================== 子表（产品对接上游配置） ====================

  // 获得产品对接上游配置分页
  getSuperiorProductConfigPage: async (params) => {
    return await request.get({ url: `/haoka/superior-api/superior-product-config/page`, params })
  },
  // 新增产品对接上游配置
  createSuperiorProductConfig: async (data) => {
    return await request.post({ url: `/haoka/superior-api/superior-product-config/create`, data })
  },

  // 修改产品对接上游配置
  updateSuperiorProductConfig: async (data) => {
    return await request.put({ url: `/haoka/superior-api/superior-product-config/update`, data })
  },

  // 删除产品对接上游配置
  deleteSuperiorProductConfig: async (id: number) => {
    return await request.delete({ url: `/haoka/superior-api/superior-product-config/delete?id=` + id })
  },

  // 获得产品对接上游配置
  getSuperiorProductConfig: async (id: number) => {
    return await request.get({ url: `/haoka/superior-api/superior-product-config/get?id=` + id })
  },
}