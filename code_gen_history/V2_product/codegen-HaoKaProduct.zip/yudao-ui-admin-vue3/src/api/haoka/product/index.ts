import request from '@/config/axios'

// 产品/渠道 VO
export interface HaoKaProductVO {
  id: number // 产品ID
  operator: number // 运营商
  sku: string // 产品编码
  name: string // 产品名称
  haokaProductTypeId: number // 产品类型
  belongAreaCode: number // 归属地
  haokaProductChannelId: number // 产品渠道
  haokaProductLimitId: number // 产品限制
  idCardNumVerify: number // 身份证号码验证
  idCardImgVerify: number // 身份证图片验证
  produceAddress: string // 生产地址
  needBlacklistFilter: boolean // 黑名单过滤
  enableStockLimit: boolean // 是否启用库存限制
  stockNum: number // 库存数量
  stockWarnNum: number // 库存报警数量
  produceRemarks: string // 生产备注
  settlementRules: string // 结算规则
  estimatedRevenue: string // 预估收益
  onSale: boolean // 上架
  isTop: boolean // 是否顶置
}

// 产品/渠道 API
export const HaoKaProductApi = {
  // 查询产品/渠道分页
  getHaoKaProductPage: async (params: any) => {
    return await request.get({ url: `/haoka/hao-ka-product/page`, params })
  },

  // 查询产品/渠道详情
  getHaoKaProduct: async (id: number) => {
    return await request.get({ url: `/haoka/hao-ka-product/get?id=` + id })
  },

  // 新增产品/渠道
  createHaoKaProduct: async (data: HaoKaProductVO) => {
    return await request.post({ url: `/haoka/hao-ka-product/create`, data })
  },

  // 修改产品/渠道
  updateHaoKaProduct: async (data: HaoKaProductVO) => {
    return await request.put({ url: `/haoka/hao-ka-product/update`, data })
  },

  // 删除产品/渠道
  deleteHaoKaProduct: async (id: number) => {
    return await request.delete({ url: `/haoka/hao-ka-product/delete?id=` + id })
  },

  // 导出产品/渠道 Excel
  exportHaoKaProduct: async (params) => {
    return await request.download({ url: `/haoka/hao-ka-product/export-excel`, params })
  },

// ==================== 子表（产品对接上游配置） ====================

  // 获得产品对接上游配置分页
  getSuperiorProductConfigPage: async (params) => {
    return await request.get({ url: `/haoka/hao-ka-product/superior-product-config/page`, params })
  },
  // 新增产品对接上游配置
  createSuperiorProductConfig: async (data) => {
    return await request.post({ url: `/haoka/hao-ka-product/superior-product-config/create`, data })
  },

  // 修改产品对接上游配置
  updateSuperiorProductConfig: async (data) => {
    return await request.put({ url: `/haoka/hao-ka-product/superior-product-config/update`, data })
  },

  // 删除产品对接上游配置
  deleteSuperiorProductConfig: async (id: number) => {
    return await request.delete({ url: `/haoka/hao-ka-product/superior-product-config/delete?id=` + id })
  },

  // 获得产品对接上游配置
  getSuperiorProductConfig: async (id: number) => {
    return await request.get({ url: `/haoka/hao-ka-product/superior-product-config/get?id=` + id })
  },
}