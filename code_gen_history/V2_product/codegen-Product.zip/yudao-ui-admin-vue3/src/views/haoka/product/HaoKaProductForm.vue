<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="运营商" prop="operator">
        <el-select v-model="formData.operator" placeholder="请选择运营商">
          <el-option
            v-for="dict in getIntDictOptions(DICT_TYPE.HAOKA_OPERATOR)"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="产品编码" prop="sku">
        <el-input v-model="formData.sku" placeholder="请输入产品编码" />
      </el-form-item>
      <el-form-item label="产品名称" prop="name">
        <el-input v-model="formData.name" placeholder="请输入产品名称" />
      </el-form-item>
      <el-form-item label="产品类型" prop="haokaProductTypeId">
        <el-input v-model="formData.haokaProductTypeId" placeholder="请输入产品类型" />
      </el-form-item>
      <el-form-item label="归属地" prop="belongAreaCode">
        <el-input v-model="formData.belongAreaCode" placeholder="请输入归属地" />
      </el-form-item>
      <el-form-item label="产品渠道" prop="haokaProductChannelId">
        <el-input v-model="formData.haokaProductChannelId" placeholder="请输入产品渠道" />
      </el-form-item>
      <el-form-item label="产品限制" prop="haokaProductLimitId">
        <el-input v-model="formData.haokaProductLimitId" placeholder="请输入产品限制" />
      </el-form-item>
      <el-form-item label="身份证号码验证" prop="idCardNumVerify">
        <el-radio-group v-model="formData.idCardNumVerify">
          <el-radio
            v-for="dict in getIntDictOptions(DICT_TYPE.ID_CARD_NUM_VERIFY)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="身份证图片验证" prop="idCardImgVerify">
        <el-radio-group v-model="formData.idCardImgVerify">
          <el-radio
            v-for="dict in getIntDictOptions(DICT_TYPE.ID_CARD_IMG_VERIFY)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="生产地址" prop="produceAddress">
        <el-input v-model="formData.produceAddress" placeholder="请输入生产地址" />
      </el-form-item>
      <el-form-item label="黑名单过滤" prop="needBlacklistFilter">
        <el-radio-group v-model="formData.needBlacklistFilter">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="是否启用库存限制" prop="enableStockLimit">
        <el-radio-group v-model="formData.enableStockLimit">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="库存数量" prop="stockNum">
        <el-input v-model="formData.stockNum" placeholder="请输入库存数量" />
      </el-form-item>
      <el-form-item label="库存报警数量" prop="stockWarnNum">
        <el-input v-model="formData.stockWarnNum" placeholder="请输入库存报警数量" />
      </el-form-item>
      <el-form-item label="生产备注" prop="produceRemarks">
        <el-input v-model="formData.produceRemarks" placeholder="请输入生产备注" />
      </el-form-item>
      <el-form-item label="结算规则" prop="settlementRules">
        <el-input v-model="formData.settlementRules" placeholder="请输入结算规则" />
      </el-form-item>
      <el-form-item label="预估收益" prop="estimatedRevenue">
        <el-input v-model="formData.estimatedRevenue" placeholder="请输入预估收益" />
      </el-form-item>
      <el-form-item label="上架" prop="onSale">
        <el-radio-group v-model="formData.onSale">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="是否顶置" prop="isTop">
        <el-radio-group v-model="formData.isTop">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { getIntDictOptions, DICT_TYPE } from '@/utils/dict'
import { HaoKaProductApi, HaoKaProductVO } from '@/api/haoka/product'

/** 产品/渠道 表单 */
defineOptions({ name: 'HaoKaProductForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  operator: undefined,
  sku: undefined,
  name: undefined,
  haokaProductTypeId: undefined,
  belongAreaCode: undefined,
  haokaProductChannelId: undefined,
  haokaProductLimitId: undefined,
  idCardNumVerify: undefined,
  idCardImgVerify: undefined,
  produceAddress: undefined,
  needBlacklistFilter: undefined,
  enableStockLimit: undefined,
  stockNum: undefined,
  stockWarnNum: undefined,
  produceRemarks: undefined,
  settlementRules: undefined,
  estimatedRevenue: undefined,
  onSale: undefined,
  isTop: undefined,
})
const formRules = reactive({
  operator: [{ required: true, message: '运营商不能为空', trigger: 'change' }],
  sku: [{ required: true, message: '产品编码不能为空', trigger: 'blur' }],
  name: [{ required: true, message: '产品名称不能为空', trigger: 'blur' }],
  belongAreaCode: [{ required: true, message: '归属地不能为空', trigger: 'blur' }],
  haokaProductLimitId: [{ required: true, message: '产品限制不能为空', trigger: 'blur' }],
  idCardNumVerify: [{ required: true, message: '身份证号码验证不能为空', trigger: 'blur' }],
  idCardImgVerify: [{ required: true, message: '身份证图片验证不能为空', trigger: 'blur' }],
  needBlacklistFilter: [{ required: true, message: '黑名单过滤不能为空', trigger: 'blur' }],
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await HaoKaProductApi.getHaoKaProduct(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as HaoKaProductVO
    if (formType.value === 'create') {
      await HaoKaProductApi.createHaoKaProduct(data)
      message.success(t('common.createSuccess'))
    } else {
      await HaoKaProductApi.updateHaoKaProduct(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    operator: undefined,
    sku: undefined,
    name: undefined,
    haokaProductTypeId: undefined,
    belongAreaCode: undefined,
    haokaProductChannelId: undefined,
    haokaProductLimitId: undefined,
    idCardNumVerify: undefined,
    idCardImgVerify: undefined,
    produceAddress: undefined,
    needBlacklistFilter: undefined,
    enableStockLimit: undefined,
    stockNum: undefined,
    stockWarnNum: undefined,
    produceRemarks: undefined,
    settlementRules: undefined,
    estimatedRevenue: undefined,
    onSale: undefined,
    isTop: undefined,
  }
  formRef.value?.resetFields()
}
</script>