<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="运营商" prop="operator">
        <el-select
          v-model="queryParams.operator"
          placeholder="请选择运营商"
          clearable
          class="!w-240px"
        >
          <el-option
            v-for="dict in getIntDictOptions(DICT_TYPE.HAOKA_OPERATOR)"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="产品编码" prop="sku">
        <el-input
          v-model="queryParams.sku"
          placeholder="请输入产品编码"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="产品名称" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入产品名称"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="产品类型" prop="haokaProductTypeId">
        <el-input
          v-model="queryParams.haokaProductTypeId"
          placeholder="请输入产品类型"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="归属地" prop="belongAreaCode">
        <el-input
          v-model="queryParams.belongAreaCode"
          placeholder="请输入归属地"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="产品渠道" prop="haokaProductChannelId">
        <el-input
          v-model="queryParams.haokaProductChannelId"
          placeholder="请输入产品渠道"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="产品限制" prop="haokaProductLimitId">
        <el-input
          v-model="queryParams.haokaProductLimitId"
          placeholder="请输入产品限制"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="身份证号码验证" prop="idCardNumVerify">
        <el-select
          v-model="queryParams.idCardNumVerify"
          placeholder="请选择身份证号码验证"
          clearable
          class="!w-240px"
        >
          <el-option
            v-for="dict in getIntDictOptions(DICT_TYPE.ID_CARD_NUM_VERIFY)"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="身份证图片验证" prop="idCardImgVerify">
        <el-select
          v-model="queryParams.idCardImgVerify"
          placeholder="请选择身份证图片验证"
          clearable
          class="!w-240px"
        >
          <el-option
            v-for="dict in getIntDictOptions(DICT_TYPE.ID_CARD_IMG_VERIFY)"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="生产地址" prop="produceAddress">
        <el-input
          v-model="queryParams.produceAddress"
          placeholder="请输入生产地址"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="黑名单过滤" prop="needBlacklistFilter">
        <el-select
          v-model="queryParams.needBlacklistFilter"
          placeholder="请选择黑名单过滤"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="是否启用库存限制" prop="enableStockLimit">
        <el-select
          v-model="queryParams.enableStockLimit"
          placeholder="请选择是否启用库存限制"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="库存数量" prop="stockNum">
        <el-input
          v-model="queryParams.stockNum"
          placeholder="请输入库存数量"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="库存报警数量" prop="stockWarnNum">
        <el-input
          v-model="queryParams.stockWarnNum"
          placeholder="请输入库存报警数量"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="生产备注" prop="produceRemarks">
        <el-input
          v-model="queryParams.produceRemarks"
          placeholder="请输入生产备注"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="结算规则" prop="settlementRules">
        <el-input
          v-model="queryParams.settlementRules"
          placeholder="请输入结算规则"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="预估收益" prop="estimatedRevenue">
        <el-input
          v-model="queryParams.estimatedRevenue"
          placeholder="请输入预估收益"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="上架" prop="onSale">
        <el-select
          v-model="queryParams.onSale"
          placeholder="请选择上架"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="是否顶置" prop="isTop">
        <el-select
          v-model="queryParams.isTop"
          placeholder="请选择是否顶置"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker
          v-model="queryParams.createTime"
          value-format="YYYY-MM-DD HH:mm:ss"
          type="daterange"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :default-time="[new Date('1 00:00:00'), new Date('1 23:59:59')]"
          class="!w-220px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['haoka:hao-ka-product:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['haoka:hao-ka-product:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table
      v-loading="loading"
      :data="list"
      :stripe="true"
      :show-overflow-tooltip="true"
      highlight-current-row
      @current-change="handleCurrentChange"
    >
      <el-table-column label="产品ID" align="center" prop="id" />
      <el-table-column label="运营商" align="center" prop="operator">
        <template #default="scope">
          <dict-tag :type="DICT_TYPE.HAOKA_OPERATOR" :value="scope.row.operator" />
        </template>
      </el-table-column>
      <el-table-column label="产品编码" align="center" prop="sku" />
      <el-table-column label="产品名称" align="center" prop="name" />
      <el-table-column label="产品类型" align="center" prop="haokaProductTypeId" />
      <el-table-column label="归属地" align="center" prop="belongAreaCode" />
      <el-table-column label="产品渠道" align="center" prop="haokaProductChannelId" />
      <el-table-column label="产品限制" align="center" prop="haokaProductLimitId" />
      <el-table-column label="身份证号码验证" align="center" prop="idCardNumVerify">
        <template #default="scope">
          <dict-tag :type="DICT_TYPE.ID_CARD_NUM_VERIFY" :value="scope.row.idCardNumVerify" />
        </template>
      </el-table-column>
      <el-table-column label="身份证图片验证" align="center" prop="idCardImgVerify">
        <template #default="scope">
          <dict-tag :type="DICT_TYPE.ID_CARD_IMG_VERIFY" :value="scope.row.idCardImgVerify" />
        </template>
      </el-table-column>
      <el-table-column label="生产地址" align="center" prop="produceAddress" />
      <el-table-column label="黑名单过滤" align="center" prop="needBlacklistFilter" />
      <el-table-column label="是否启用库存限制" align="center" prop="enableStockLimit" />
      <el-table-column label="库存数量" align="center" prop="stockNum" />
      <el-table-column label="库存报警数量" align="center" prop="stockWarnNum" />
      <el-table-column label="生产备注" align="center" prop="produceRemarks" />
      <el-table-column label="结算规则" align="center" prop="settlementRules" />
      <el-table-column label="预估收益" align="center" prop="estimatedRevenue" />
      <el-table-column label="上架" align="center" prop="onSale" />
      <el-table-column label="是否顶置" align="center" prop="isTop" />
      <el-table-column
        label="创建时间"
        align="center"
        prop="createTime"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['haoka:hao-ka-product:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['haoka:hao-ka-product:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <HaoKaProductForm ref="formRef" @success="getList" />
  <!-- 子表的列表 -->
  <ContentWrap>
    <el-tabs model-value="superiorProductConfig">
      <el-tab-pane label="产品对接上游配置" name="superiorProductConfig">
        <SuperiorProductConfigList :haoka-product-id="currentRow.id" />
      </el-tab-pane>
    </el-tabs>
  </ContentWrap>
</template>

<script setup lang="ts">
import { getIntDictOptions, DICT_TYPE } from '@/utils/dict'
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { HaoKaProductApi, HaoKaProductVO } from '@/api/haoka/product'
import HaoKaProductForm from './HaoKaProductForm.vue'
import SuperiorProductConfigList from './components/SuperiorProductConfigList.vue'

/** 产品/渠道 列表 */
defineOptions({ name: 'HaoKaProduct' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<HaoKaProductVO[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  operator: undefined,
  sku: undefined,
  name: undefined,
  haokaProductTypeId: undefined,
  belongAreaCode: undefined,
  haokaProductChannelId: undefined,
  haokaProductLimitId: undefined,
  idCardNumVerify: undefined,
  idCardImgVerify: undefined,
  produceAddress: undefined,
  needBlacklistFilter: undefined,
  enableStockLimit: undefined,
  stockNum: undefined,
  stockWarnNum: undefined,
  produceRemarks: undefined,
  settlementRules: undefined,
  estimatedRevenue: undefined,
  onSale: undefined,
  isTop: undefined,
  createTime: [],
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await HaoKaProductApi.getHaoKaProductPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await HaoKaProductApi.deleteHaoKaProduct(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await HaoKaProductApi.exportHaoKaProduct(queryParams)
    download.excel(data, '产品/渠道.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 选中行操作 */
const currentRow = ref({}) // 选中行
const handleCurrentChange = (row) => {
  currentRow.value = row
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>