import request from '@/config/axios'

// 产品的渠道 VO
export interface ProductChannelVO {
  id: number // 产品类型ID
  name: string // 产品类型名称
}

// 产品的渠道 API
export const ProductChannelApi = {
  // 查询产品的渠道分页
  getProductChannelPage: async (params: any) => {
    return await request.get({ url: `/haoka/product-channel/page`, params })
  },

  // 查询产品的渠道详情
  getProductChannel: async (id: number) => {
    return await request.get({ url: `/haoka/product-channel/get?id=` + id })
  },

  // 新增产品的渠道
  createProductChannel: async (data: ProductChannelVO) => {
    return await request.post({ url: `/haoka/product-channel/create`, data })
  },

  // 修改产品的渠道
  updateProductChannel: async (data: ProductChannelVO) => {
    return await request.put({ url: `/haoka/product-channel/update`, data })
  },

  // 删除产品的渠道
  deleteProductChannel: async (id: number) => {
    return await request.delete({ url: `/haoka/product-channel/delete?id=` + id })
  },

  // 导出产品的渠道 Excel
  exportProductChannel: async (params) => {
    return await request.download({ url: `/haoka/product-channel/export-excel`, params })
  },
}