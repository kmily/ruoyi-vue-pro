import request from '@/config/axios'

// 产品限制条件 VO
export interface ProductLimitVO {
  id: number // 产品类型ID
  name: string // 产品类型名称
  useOnlySendArea: boolean // 是否使用只发货地址
  useNotSendArea: boolean // 是否使用不发货地址
  useCardLimit: boolean // 是否使用身份证限制
  ageMax: number // 最大年龄限制
  ageMin: number // 最小年龄限制
  personCardQuantityLimit: number // 单人开卡数量限制
  detectionCycle: number // 检测周期(月)
}

// 产品限制条件 API
export const ProductLimitApi = {
  // 查询产品限制条件分页
  getProductLimitPage: async (params: any) => {
    return await request.get({ url: `/haoka/product-limit/page`, params })
  },

  // 查询产品限制条件详情
  getProductLimit: async (id: number) => {
    return await request.get({ url: `/haoka/product-limit/get?id=` + id })
  },

  // 新增产品限制条件
  createProductLimit: async (data: ProductLimitVO) => {
    return await request.post({ url: `/haoka/product-limit/create`, data })
  },

  // 修改产品限制条件
  updateProductLimit: async (data: ProductLimitVO) => {
    return await request.put({ url: `/haoka/product-limit/update`, data })
  },

  // 删除产品限制条件
  deleteProductLimit: async (id: number) => {
    return await request.delete({ url: `/haoka/product-limit/delete?id=` + id })
  },

  // 导出产品限制条件 Excel
  exportProductLimit: async (params) => {
    return await request.download({ url: `/haoka/product-limit/export-excel`, params })
  },

// ==================== 子表（产品身份证限制） ====================

  // 获得产品身份证限制分页
  getProductLimitCardPage: async (params) => {
    return await request.get({ url: `/haoka/product-limit/product-limit-card/page`, params })
  },
  // 新增产品身份证限制
  createProductLimitCard: async (data) => {
    return await request.post({ url: `/haoka/product-limit/product-limit-card/create`, data })
  },

  // 修改产品身份证限制
  updateProductLimitCard: async (data) => {
    return await request.put({ url: `/haoka/product-limit/product-limit-card/update`, data })
  },

  // 删除产品身份证限制
  deleteProductLimitCard: async (id: number) => {
    return await request.delete({ url: `/haoka/product-limit/product-limit-card/delete?id=` + id })
  },

  // 获得产品身份证限制
  getProductLimitCard: async (id: number) => {
    return await request.get({ url: `/haoka/product-limit/product-limit-card/get?id=` + id })
  },
}