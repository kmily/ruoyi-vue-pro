import request from '@/config/axios'

// 产品对接上游配置 VO
export interface SuperiorProductConfigVO {
  id: number // ID
  haokaSuperiorApiId: number // 上游接口ID
  haokaProductId: number // 产品ID
  isConfined: boolean // 是否已配置
  config: string // 值
  remarks: string // 说明
}

// 产品对接上游配置 API
export const SuperiorProductConfigApi = {
  // 查询产品对接上游配置分页
  getSuperiorProductConfigPage: async (params: any) => {
    return await request.get({ url: `/haoka/superior-product-config/page`, params })
  },

  // 查询产品对接上游配置详情
  getSuperiorProductConfig: async (id: number) => {
    return await request.get({ url: `/haoka/superior-product-config/get?id=` + id })
  },

  // 新增产品对接上游配置
  createSuperiorProductConfig: async (data: SuperiorProductConfigVO) => {
    return await request.post({ url: `/haoka/superior-product-config/create`, data })
  },

  // 修改产品对接上游配置
  updateSuperiorProductConfig: async (data: SuperiorProductConfigVO) => {
    return await request.put({ url: `/haoka/superior-product-config/update`, data })
  },

  // 删除产品对接上游配置
  deleteSuperiorProductConfig: async (id: number) => {
    return await request.delete({ url: `/haoka/superior-product-config/delete?id=` + id })
  },

  // 导出产品对接上游配置 Excel
  exportSuperiorProductConfig: async (params) => {
    return await request.download({ url: `/haoka/superior-product-config/export-excel`, params })
  },
}