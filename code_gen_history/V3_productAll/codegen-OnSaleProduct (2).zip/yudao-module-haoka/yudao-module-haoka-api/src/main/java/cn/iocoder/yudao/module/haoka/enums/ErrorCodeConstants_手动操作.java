// TODO 待办：请将下面的错误码复制到 yudao-module-haoka-api 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 在售产品 TODO 补充编号 ==========
ErrorCode ON_SALE_PRODUCT_NOT_EXISTS = new ErrorCode(TODO 补充编号, "在售产品不存在");