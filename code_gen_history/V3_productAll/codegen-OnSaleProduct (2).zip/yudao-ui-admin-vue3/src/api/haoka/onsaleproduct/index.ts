import request from '@/config/axios'

// 在售产品 VO
export interface OnSaleProductVO {
  id: number // ID
  parentProductId: number // 产品
  name: string // 商品名称
  sku: string // 商家编码
  precautions: string // 商品注意点
  sellingPoints: string // 卖点，使用逗号隔开
  acceptanceRules: string // 承接佣金规则
  settlementRequirement: string // 结算要求
  settlementRulesInner: string // 佣金结算规则（内部）
  needSaleUploadImage: boolean // 销售页上传照片
  mainImg: string // 产品主图
  shareImg: string // 商品分享图
  detail: string // 商品详情
  otherNote: string // 其他备注
  monthlyRent: string // 月租
  voiceCall: string // 语言通话
  universalTraffic: string // 通用流量
  targetedTraffic: string // 定向流量
  belongArea: string // 归属地
  packageDetails: string // 套餐详情
  packageDiscountPeriod: number // 套餐优惠期
  packageDiscountPeriodStart: number // 优惠期起始时间:当月，次月，三月
  onSale: boolean // 上架
  isTop: boolean // 是否顶置
}

// 在售产品 API
export const OnSaleProductApi = {
  // 查询在售产品分页
  getOnSaleProductPage: async (params: any) => {
    return await request.get({ url: `/haoka/on-sale-product/page`, params })
  },

  // 查询在售产品详情
  getOnSaleProduct: async (id: number) => {
    return await request.get({ url: `/haoka/on-sale-product/get?id=` + id })
  },

  // 新增在售产品
  createOnSaleProduct: async (data: OnSaleProductVO) => {
    return await request.post({ url: `/haoka/on-sale-product/create`, data })
  },

  // 修改在售产品
  updateOnSaleProduct: async (data: OnSaleProductVO) => {
    return await request.put({ url: `/haoka/on-sale-product/update`, data })
  },

  // 删除在售产品
  deleteOnSaleProduct: async (id: number) => {
    return await request.delete({ url: `/haoka/on-sale-product/delete?id=` + id })
  },

  // 导出在售产品 Excel
  exportOnSaleProduct: async (params) => {
    return await request.download({ url: `/haoka/on-sale-product/export-excel`, params })
  },
}