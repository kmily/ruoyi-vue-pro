<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="产品" prop="parentProductId">
        <el-input v-model="formData.parentProductId" placeholder="请输入产品" />
      </el-form-item>
      <el-form-item label="商品名称" prop="name">
        <el-input v-model="formData.name" placeholder="请输入商品名称" />
      </el-form-item>
      <el-form-item label="商家编码" prop="sku">
        <el-input v-model="formData.sku" placeholder="请输入商家编码" />
      </el-form-item>
      <el-form-item label="商品注意点" prop="precautions">
        <el-input v-model="formData.precautions" placeholder="请输入商品注意点" />
      </el-form-item>
      <el-form-item label="卖点，使用逗号隔开" prop="sellingPoints">
        <el-input v-model="formData.sellingPoints" placeholder="请输入卖点，使用逗号隔开" />
      </el-form-item>
      <el-form-item label="承接佣金规则" prop="acceptanceRules">
        <el-input v-model="formData.acceptanceRules" placeholder="请输入承接佣金规则" />
      </el-form-item>
      <el-form-item label="结算要求" prop="settlementRequirement">
        <el-input v-model="formData.settlementRequirement" placeholder="请输入结算要求" />
      </el-form-item>
      <el-form-item label="佣金结算规则（内部）" prop="settlementRulesInner">
        <el-input v-model="formData.settlementRulesInner" placeholder="请输入佣金结算规则（内部）" />
      </el-form-item>
      <el-form-item label="销售页上传照片" prop="needSaleUploadImage">
        <el-radio-group v-model="formData.needSaleUploadImage">
          <el-radio
            v-for="dict in getBoolDictOptions(DICT_TYPE.INFRA_BOOLEAN_STRING)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="产品主图" prop="mainImg">
        <UploadImg v-model="formData.mainImg" />
      </el-form-item>
      <el-form-item label="商品分享图" prop="shareImg">
        <UploadImg v-model="formData.shareImg" />
      </el-form-item>
      <el-form-item label="商品详情" prop="detail">
        <Editor v-model="formData.detail" height="150px" />
      </el-form-item>
      <el-form-item label="其他备注" prop="otherNote">
        <Editor v-model="formData.otherNote" height="150px" />
      </el-form-item>
      <el-form-item label="月租" prop="monthlyRent">
        <el-input v-model="formData.monthlyRent" placeholder="请输入月租" />
      </el-form-item>
      <el-form-item label="语言通话" prop="voiceCall">
        <el-input v-model="formData.voiceCall" placeholder="请输入语言通话" />
      </el-form-item>
      <el-form-item label="通用流量" prop="universalTraffic">
        <el-input v-model="formData.universalTraffic" placeholder="请输入通用流量" />
      </el-form-item>
      <el-form-item label="定向流量" prop="targetedTraffic">
        <el-input v-model="formData.targetedTraffic" placeholder="请输入定向流量" />
      </el-form-item>
      <el-form-item label="归属地" prop="belongArea">
        <el-input v-model="formData.belongArea" placeholder="请输入归属地" />
      </el-form-item>
      <el-form-item label="套餐详情" prop="packageDetails">
        <el-input v-model="formData.packageDetails" placeholder="请输入套餐详情" />
      </el-form-item>
      <el-form-item label="套餐优惠期" prop="packageDiscountPeriod">
        <el-input v-model="formData.packageDiscountPeriod" placeholder="请输入套餐优惠期" />
      </el-form-item>
      <el-form-item label="优惠期起始时间:当月，次月，三月" prop="packageDiscountPeriodStart">
        <el-input v-model="formData.packageDiscountPeriodStart" placeholder="请输入优惠期起始时间:当月，次月，三月" />
      </el-form-item>
      <el-form-item label="上架" prop="onSale">
        <el-radio-group v-model="formData.onSale">
          <el-radio
            v-for="dict in getBoolDictOptions(DICT_TYPE.INFRA_BOOLEAN_STRING)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="是否顶置" prop="isTop">
        <el-radio-group v-model="formData.isTop">
          <el-radio
            v-for="dict in getBoolDictOptions(DICT_TYPE.INFRA_BOOLEAN_STRING)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { getBoolDictOptions, DICT_TYPE } from '@/utils/dict'
import { OnSaleProductApi, OnSaleProductVO } from '@/api/haoka/onsaleproduct'

/** 在售产品 表单 */
defineOptions({ name: 'OnSaleProductForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  parentProductId: undefined,
  name: undefined,
  sku: undefined,
  precautions: undefined,
  sellingPoints: undefined,
  acceptanceRules: undefined,
  settlementRequirement: undefined,
  settlementRulesInner: undefined,
  needSaleUploadImage: undefined,
  mainImg: undefined,
  shareImg: undefined,
  detail: undefined,
  otherNote: undefined,
  monthlyRent: undefined,
  voiceCall: undefined,
  universalTraffic: undefined,
  targetedTraffic: undefined,
  belongArea: undefined,
  packageDetails: undefined,
  packageDiscountPeriod: undefined,
  packageDiscountPeriodStart: undefined,
  onSale: undefined,
  isTop: undefined,
})
const formRules = reactive({
  parentProductId: [{ required: true, message: '产品不能为空', trigger: 'blur' }],
  name: [{ required: true, message: '商品名称不能为空', trigger: 'blur' }],
  sku: [{ required: true, message: '商家编码不能为空', trigger: 'blur' }],
  needSaleUploadImage: [{ required: true, message: '销售页上传照片不能为空', trigger: 'blur' }],
  onSale: [{ required: true, message: '上架不能为空', trigger: 'blur' }],
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await OnSaleProductApi.getOnSaleProduct(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as OnSaleProductVO
    if (formType.value === 'create') {
      await OnSaleProductApi.createOnSaleProduct(data)
      message.success(t('common.createSuccess'))
    } else {
      await OnSaleProductApi.updateOnSaleProduct(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    parentProductId: undefined,
    name: undefined,
    sku: undefined,
    precautions: undefined,
    sellingPoints: undefined,
    acceptanceRules: undefined,
    settlementRequirement: undefined,
    settlementRulesInner: undefined,
    needSaleUploadImage: undefined,
    mainImg: undefined,
    shareImg: undefined,
    detail: undefined,
    otherNote: undefined,
    monthlyRent: undefined,
    voiceCall: undefined,
    universalTraffic: undefined,
    targetedTraffic: undefined,
    belongArea: undefined,
    packageDetails: undefined,
    packageDiscountPeriod: undefined,
    packageDiscountPeriodStart: undefined,
    onSale: undefined,
    isTop: undefined,
  }
  formRef.value?.resetFields()
}
</script>