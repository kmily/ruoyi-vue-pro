package cn.iocoder.yudao.module.haoka.dal.mysql.product;

import java.util.*;

import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.framework.common.pojo.PageParam;
import cn.iocoder.yudao.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.yudao.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.yudao.module.haoka.dal.dataobject.product.ProductLimitCardDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 产品身份证限制 Mapper
 *
 * @author 芋道源码
 */
@Mapper
public interface ProductLimitCardMapper extends BaseMapperX<ProductLimitCardDO> {

    default List<ProductLimitCardDO> selectListByHaokaProductLimitId(Long haokaProductLimitId) {
        return selectList(ProductLimitCardDO::getHaokaProductLimitId, haokaProductLimitId);
    }

    default int deleteByHaokaProductLimitId(Long haokaProductLimitId) {
        return delete(ProductLimitCardDO::getHaokaProductLimitId, haokaProductLimitId);
    }

}