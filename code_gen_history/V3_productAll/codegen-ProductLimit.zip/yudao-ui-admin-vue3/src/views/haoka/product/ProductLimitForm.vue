<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="产品类型名称" prop="name">
        <el-input v-model="formData.name" placeholder="请输入产品类型名称" />
      </el-form-item>
      <el-form-item label="是否使用只发货地址" prop="useOnlySendArea">
        <el-radio-group v-model="formData.useOnlySendArea">
          <el-radio
            v-for="dict in getBoolDictOptions(DICT_TYPE.INFRA_BOOLEAN_STRING)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="是否使用不发货地址" prop="useNotSendArea">
        <el-radio-group v-model="formData.useNotSendArea">
          <el-radio
            v-for="dict in getBoolDictOptions(DICT_TYPE.INFRA_BOOLEAN_STRING)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="是否使用身份证限制" prop="useCardLimit">
        <el-radio-group v-model="formData.useCardLimit">
          <el-radio
            v-for="dict in getBoolDictOptions(DICT_TYPE.INFRA_BOOLEAN_STRING)"
            :key="dict.value"
            :label="dict.value"
          >
            {{ dict.label }}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="最大年龄限制" prop="ageMax">
        <el-input v-model="formData.ageMax" placeholder="请输入最大年龄限制" />
      </el-form-item>
      <el-form-item label="最小年龄限制" prop="ageMin">
        <el-input v-model="formData.ageMin" placeholder="请输入最小年龄限制" />
      </el-form-item>
      <el-form-item label="单人开卡数量限制" prop="personCardQuantityLimit">
        <el-input v-model="formData.personCardQuantityLimit" placeholder="请输入单人开卡数量限制" />
      </el-form-item>
      <el-form-item label="检测周期(月)" prop="detectionCycle">
        <el-input v-model="formData.detectionCycle" placeholder="请输入检测周期(月)" />
      </el-form-item>
    </el-form>
    <!-- 子表的表单 -->
    <el-tabs v-model="subTabsName">
      <el-tab-pane label="产品区域配置" name="productLimitArea">
        <ProductLimitAreaForm ref="productLimitAreaFormRef" :haoka-product-limit-id="formData.id" />
      </el-tab-pane>
      <el-tab-pane label="产品身份证限制" name="productLimitCard">
        <ProductLimitCardForm ref="productLimitCardFormRef" :haoka-product-limit-id="formData.id" />
      </el-tab-pane>
    </el-tabs>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { getBoolDictOptions, DICT_TYPE } from '@/utils/dict'
import { ProductLimitApi, ProductLimitVO } from '@/api/haoka/product'
import ProductLimitAreaForm from './components/ProductLimitAreaForm.vue'
import ProductLimitCardForm from './components/ProductLimitCardForm.vue'

/** 产品限制条件 表单 */
defineOptions({ name: 'ProductLimitForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  name: undefined,
  useOnlySendArea: undefined,
  useNotSendArea: undefined,
  useCardLimit: undefined,
  ageMax: undefined,
  ageMin: undefined,
  personCardQuantityLimit: undefined,
  detectionCycle: undefined,
})
const formRules = reactive({
  name: [{ required: true, message: '产品类型名称不能为空', trigger: 'blur' }],
  useOnlySendArea: [{ required: true, message: '是否使用只发货地址不能为空', trigger: 'blur' }],
  useNotSendArea: [{ required: true, message: '是否使用不发货地址不能为空', trigger: 'blur' }],
  useCardLimit: [{ required: true, message: '是否使用身份证限制不能为空', trigger: 'blur' }],
})
const formRef = ref() // 表单 Ref

/** 子表的表单 */
const subTabsName = ref('productLimitArea')
const productLimitAreaFormRef = ref()
const productLimitCardFormRef = ref()

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await ProductLimitApi.getProductLimit(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 校验子表单
  try {
    await productLimitAreaFormRef.value.validate()
  } catch (e) {
    subTabsName.value = 'productLimitArea'
    return
  }
  try {
    await productLimitCardFormRef.value.validate()
  } catch (e) {
    subTabsName.value = 'productLimitCard'
    return
  }
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as ProductLimitVO
    // 拼接子表的数据
    data.productLimitAreas = productLimitAreaFormRef.value.getData()
    data.productLimitCards = productLimitCardFormRef.value.getData()
    if (formType.value === 'create') {
      await ProductLimitApi.createProductLimit(data)
      message.success(t('common.createSuccess'))
    } else {
      await ProductLimitApi.updateProductLimit(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    name: undefined,
    useOnlySendArea: undefined,
    useNotSendArea: undefined,
    useCardLimit: undefined,
    ageMax: undefined,
    ageMin: undefined,
    personCardQuantityLimit: undefined,
    detectionCycle: undefined,
  }
  formRef.value?.resetFields()
}
</script>