import request from '@/config/axios'

// 产品区域配置 VO
export interface ProductLimitAreaVO {
  id: number // ID
  haokaProductLimitId: number // 产品限制ID
  addressCode: number // 地区
  addressName: string // 地区
  allowed: boolean // 是否允许
}

// 产品区域配置 API
export const ProductLimitAreaApi = {
  // 查询产品区域配置分页
  getProductLimitAreaPage: async (params: any) => {
    return await request.get({ url: `/haoka/product-limit-area/page`, params })
  },

  // 查询产品区域配置详情
  getProductLimitArea: async (id: number) => {
    return await request.get({ url: `/haoka/product-limit-area/get?id=` + id })
  },

  // 新增产品区域配置
  createProductLimitArea: async (data: ProductLimitAreaVO) => {
    return await request.post({ url: `/haoka/product-limit-area/create`, data })
  },

  // 修改产品区域配置
  updateProductLimitArea: async (data: ProductLimitAreaVO) => {
    return await request.put({ url: `/haoka/product-limit-area/update`, data })
  },

  // 删除产品区域配置
  deleteProductLimitArea: async (id: number) => {
    return await request.delete({ url: `/haoka/product-limit-area/delete?id=` + id })
  },

  // 导出产品区域配置 Excel
  exportProductLimitArea: async (params) => {
    return await request.download({ url: `/haoka/product-limit-area/export-excel`, params })
  },
}