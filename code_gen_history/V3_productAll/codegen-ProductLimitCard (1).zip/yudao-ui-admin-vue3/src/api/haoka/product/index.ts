import request from '@/config/axios'

// 产品身份证限制 VO
export interface ProductLimitCardVO {
  id: number // ID
  haokaProductLimitId: number // 产品限制ID
  cardNum: number // 身份证号前4或6位
}

// 产品身份证限制 API
export const ProductLimitCardApi = {
  // 查询产品身份证限制分页
  getProductLimitCardPage: async (params: any) => {
    return await request.get({ url: `/haoka/product-limit-card/page`, params })
  },

  // 查询产品身份证限制详情
  getProductLimitCard: async (id: number) => {
    return await request.get({ url: `/haoka/product-limit-card/get?id=` + id })
  },

  // 新增产品身份证限制
  createProductLimitCard: async (data: ProductLimitCardVO) => {
    return await request.post({ url: `/haoka/product-limit-card/create`, data })
  },

  // 修改产品身份证限制
  updateProductLimitCard: async (data: ProductLimitCardVO) => {
    return await request.put({ url: `/haoka/product-limit-card/update`, data })
  },

  // 删除产品身份证限制
  deleteProductLimitCard: async (id: number) => {
    return await request.delete({ url: `/haoka/product-limit-card/delete?id=` + id })
  },

  // 导出产品身份证限制 Excel
  exportProductLimitCard: async (params) => {
    return await request.download({ url: `/haoka/product-limit-card/export-excel`, params })
  },
}