import request from '@/config/axios'

// 产品类型 VO
export interface ProductTypeVO {
  id: number // 产品类型ID
  name: string // 产品类型名称
}

// 产品类型 API
export const ProductTypeApi = {
  // 查询产品类型分页
  getProductTypePage: async (params: any) => {
    return await request.get({ url: `/haoka/product-type/page`, params })
  },

  // 查询产品类型详情
  getProductType: async (id: number) => {
    return await request.get({ url: `/haoka/product-type/get?id=` + id })
  },

  // 新增产品类型
  createProductType: async (data: ProductTypeVO) => {
    return await request.post({ url: `/haoka/product-type/create`, data })
  },

  // 修改产品类型
  updateProductType: async (data: ProductTypeVO) => {
    return await request.put({ url: `/haoka/product-type/update`, data })
  },

  // 删除产品类型
  deleteProductType: async (id: number) => {
    return await request.delete({ url: `/haoka/product-type/delete?id=` + id })
  },

  // 导出产品类型 Excel
  exportProductType: async (params) => {
    return await request.download({ url: `/haoka/product-type/export-excel`, params })
  },
}