package cn.iocoder.yudao.module.haoka.dal.mysql.superiorapi;

import java.util.*;

import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.framework.common.pojo.PageParam;
import cn.iocoder.yudao.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.yudao.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.yudao.module.haoka.dal.dataobject.superiorapi.SuperiorApiDevConfigDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 上游API接口开发配置 Mapper
 *
 * @author 芋道源码
 */
@Mapper
public interface SuperiorApiDevConfigMapper extends BaseMapperX<SuperiorApiDevConfigDO> {

    default PageResult<SuperiorApiDevConfigDO> selectPage(PageParam reqVO, Long haokaSuperiorApiId) {
        return selectPage(reqVO, new LambdaQueryWrapperX<SuperiorApiDevConfigDO>()
            .eq(SuperiorApiDevConfigDO::getHaokaSuperiorApiId, haokaSuperiorApiId)
            .orderByDesc(SuperiorApiDevConfigDO::getId));
    }

    default int deleteByHaokaSuperiorApiId(Long haokaSuperiorApiId) {
        return delete(SuperiorApiDevConfigDO::getHaokaSuperiorApiId, haokaSuperiorApiId);
    }

}