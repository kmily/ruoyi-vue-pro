-- 菜单 SQL
INSERT INTO system_menu(
    name, permission, type, sort, parent_id,
    path, icon, component, status, component_name
)
VALUES (
    '上游API接口开发配置管理', '', 2, 0, 2912,
    'superior-api-dev-config', '', 'haoka/superiorapi/index', 0, 'SuperiorApiDevConfig'
);

-- 按钮父菜单ID
-- 暂时只支持 MySQL。如果你是 Oracle、PostgreSQL、SQLServer 的话，需要手动修改 @parentId 的部分的代码
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
INSERT INTO system_menu(
    name, permission, type, sort, parent_id,
    path, icon, component, status
)
VALUES (
    '上游API接口开发配置查询', 'haoka:superior-api-dev-config:query', 3, 1, @parentId,
    '', '', '', 0
);
INSERT INTO system_menu(
    name, permission, type, sort, parent_id,
    path, icon, component, status
)
VALUES (
    '上游API接口开发配置创建', 'haoka:superior-api-dev-config:create', 3, 2, @parentId,
    '', '', '', 0
);
INSERT INTO system_menu(
    name, permission, type, sort, parent_id,
    path, icon, component, status
)
VALUES (
    '上游API接口开发配置更新', 'haoka:superior-api-dev-config:update', 3, 3, @parentId,
    '', '', '', 0
);
INSERT INTO system_menu(
    name, permission, type, sort, parent_id,
    path, icon, component, status
)
VALUES (
    '上游API接口开发配置删除', 'haoka:superior-api-dev-config:delete', 3, 4, @parentId,
    '', '', '', 0
);
INSERT INTO system_menu(
    name, permission, type, sort, parent_id,
    path, icon, component, status
)
VALUES (
    '上游API接口开发配置导出', 'haoka:superior-api-dev-config:export', 3, 5, @parentId,
    '', '', '', 0
);