import request from '@/config/axios'

// 上游API接口SKU要求配置 VO
export interface SuperiorApiSkuConfigVO {
  id: number // ID
  haokaSuperiorApiId: number // ID
  code: string // 标识
  name: string // 名字
  required: boolean // 是否必填
  remarks: string // 说明
  inputType: number // 输入类型
  inputSelectValues: string // 选项(逗号,分割)
}

// 上游API接口SKU要求配置 API
export const SuperiorApiSkuConfigApi = {
  // 查询上游API接口SKU要求配置分页
  getSuperiorApiSkuConfigPage: async (params: any) => {
    return await request.get({ url: `/haoka/superior-api-sku-config/page`, params })
  },

  // 查询上游API接口SKU要求配置详情
  getSuperiorApiSkuConfig: async (id: number) => {
    return await request.get({ url: `/haoka/superior-api-sku-config/get?id=` + id })
  },

  // 新增上游API接口SKU要求配置
  createSuperiorApiSkuConfig: async (data: SuperiorApiSkuConfigVO) => {
    return await request.post({ url: `/haoka/superior-api-sku-config/create`, data })
  },

  // 修改上游API接口SKU要求配置
  updateSuperiorApiSkuConfig: async (data: SuperiorApiSkuConfigVO) => {
    return await request.put({ url: `/haoka/superior-api-sku-config/update`, data })
  },

  // 删除上游API接口SKU要求配置
  deleteSuperiorApiSkuConfig: async (id: number) => {
    return await request.delete({ url: `/haoka/superior-api-sku-config/delete?id=` + id })
  },

  // 导出上游API接口SKU要求配置 Excel
  exportSuperiorApiSkuConfig: async (params) => {
    return await request.download({ url: `/haoka/superior-api-sku-config/export-excel`, params })
  },
}