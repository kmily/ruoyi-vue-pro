// TODO 待办：请将下面的错误码复制到 yudao-module-haoka-api 模块的 ErrorCodeConstants 类中。注意，请给“TODO 补充编号”设置一个错误码编号！！！
// ========== 订单来源配置 TODO 补充编号 ==========
ErrorCode ORDER_SOURCE_NOT_EXISTS = new ErrorCode(TODO 补充编号, "订单来源配置不存在");
ErrorCode ORDER_SOURCE_LIVE_NOT_EXISTS = new ErrorCode(TODO 补充编号, "订单来源-直播间配置不存在");