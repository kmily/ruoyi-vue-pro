import request from '@/config/axios'

// 订单来源配置 VO
export interface OrderSourceVO {
  id: number // 来源ID
  sourceRemark: string // 来源备注
  channel: number // 渠道ID
}

// 订单来源配置 API
export const OrderSourceApi = {
  // 查询订单来源配置分页
  getOrderSourcePage: async (params: any) => {
    return await request.get({ url: `/haoka/order-source/page`, params })
  },

  // 查询订单来源配置详情
  getOrderSource: async (id: number) => {
    return await request.get({ url: `/haoka/order-source/get?id=` + id })
  },

  // 新增订单来源配置
  createOrderSource: async (data: OrderSourceVO) => {
    return await request.post({ url: `/haoka/order-source/create`, data })
  },

  // 修改订单来源配置
  updateOrderSource: async (data: OrderSourceVO) => {
    return await request.put({ url: `/haoka/order-source/update`, data })
  },

  // 删除订单来源配置
  deleteOrderSource: async (id: number) => {
    return await request.delete({ url: `/haoka/order-source/delete?id=` + id })
  },

  // 导出订单来源配置 Excel
  exportOrderSource: async (params) => {
    return await request.download({ url: `/haoka/order-source/export-excel`, params })
  },

// ==================== 子表（订单来源-直播间配置） ====================

  // 获得订单来源-直播间配置分页
  getOrderSourceLivePage: async (params) => {
    return await request.get({ url: `/haoka/order-source/order-source-live/page`, params })
  },
  // 新增订单来源-直播间配置
  createOrderSourceLive: async (data) => {
    return await request.post({ url: `/haoka/order-source/order-source-live/create`, data })
  },

  // 修改订单来源-直播间配置
  updateOrderSourceLive: async (data) => {
    return await request.put({ url: `/haoka/order-source/order-source-live/update`, data })
  },

  // 删除订单来源-直播间配置
  deleteOrderSourceLive: async (id: number) => {
    return await request.delete({ url: `/haoka/order-source/order-source-live/delete?id=` + id })
  },

  // 获得订单来源-直播间配置
  getOrderSourceLive: async (id: number) => {
    return await request.get({ url: `/haoka/order-source/order-source-live/get?id=` + id })
  },
}