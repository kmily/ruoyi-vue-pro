import request from '@/config/axios'

// 订单 VO
export interface OrdersVO {
  id: number // 订单ID
  producerId: number // 生产商ID
  productId: number // 产品ID
  supplierProductName: string // 供应商-商品名称
  supplierProductSku: string // 供应商-商品编码SKU
  sourceId: string // 外部订单编号
  shareId: number // 分享ID
  userId: number // 用户ID
  productSku: string // 产品SKU
  sourceSku: string // 外部SKU
  planMobile: string // 计划手机号
  planMobileProduced: string // 生产手机号
  idCardName: string // 证件姓名
  idCardNum: string // 证件号码
  addressProvinceCode: string // 地址省编码
  addressCityCode: string // 地址市编码
  addressDistrictCode: string // 地址区编码
  addressProvince: string // 地址省
  addressCity: string // 地址市
  addressDistrict: string // 地址区
  address: string // 详细地址
  addressMobile: string // 收件人电话
  addressName: string // 收件人姓名
  trackingCompanyId: number // 物流公司ID
  trackingNumber: string // 物流单号
  buyerMemo: string // 买家备注
  sellerMemo: string // 卖家备注
  producerMemo: string // 生产备注
  status: number // 订单状态码
  flag: number // 标志
  warnArea: string // 预警区域
  reason: string // 原因
  source: string // 订单来源
  orderedAt: Date // 用户下单时间
  producedAt: Date // 生产时间
  deliveredAt: Date // 发货时间
  activatedAt: Date // 激活时间
  rechargedAt: Date // 充值时间
  memo: string // 卖家备注
  amount: string // 数量
  statusUpdatedAt: Date // 状态变更时间
  refundStatus: string // 退款状态
  activeStatus: string // 激活状态
  iccid: string // ICCID
  realSourceId: string // 真实外部订单编号
  picSize: number // 图片大小
  regionP: string // 归属地省
  regionC: string // 归属地市
  merchantName: string // 分销商名称
  upStatus: string // 上游状态
  upstreamOrderId: string // 上游订单号
  town: string // 镇/乡
  trackingCompany: string // 物流公司名称
  statusName: string // 订单状态名称
  encryptAddressMobile: string // 加密收货电话
  encryptAddressName: string // 加密收货人姓名
  encryptIdCardName: string // 加密证件姓名
  encryptIdCardNum: string // 加密证件号码
  encryptAddress: string // 加密详细地址
}

// 订单 API
export const OrdersApi = {
  // 查询订单分页
  getOrdersPage: async (params: any) => {
    return await request.get({ url: `/haoka/orders/page`, params })
  },

  // 查询订单详情
  getOrders: async (id: number) => {
    return await request.get({ url: `/haoka/orders/get?id=` + id })
  },

  // 新增订单
  createOrders: async (data: OrdersVO) => {
    return await request.post({ url: `/haoka/orders/create`, data })
  },

  // 修改订单
  updateOrders: async (data: OrdersVO) => {
    return await request.put({ url: `/haoka/orders/update`, data })
  },

  // 删除订单
  deleteOrders: async (id: number) => {
    return await request.delete({ url: `/haoka/orders/delete?id=` + id })
  },

  // 导出订单 Excel
  exportOrders: async (params) => {
    return await request.download({ url: `/haoka/orders/export-excel`, params })
  },
}