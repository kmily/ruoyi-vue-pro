<template>
  <Dialog :title="dialogTitle" v-model="dialogVisible">
    <el-form
      ref="formRef"
      :model="formData"
      :rules="formRules"
      label-width="100px"
      v-loading="formLoading"
    >
      <el-form-item label="生产商ID" prop="producerId">
        <el-input v-model="formData.producerId" placeholder="请输入生产商ID" />
      </el-form-item>
      <el-form-item label="产品ID" prop="productId">
        <el-input v-model="formData.productId" placeholder="请输入产品ID" />
      </el-form-item>
      <el-form-item label="供应商-商品名称" prop="supplierProductName">
        <el-input v-model="formData.supplierProductName" placeholder="请输入供应商-商品名称" />
      </el-form-item>
      <el-form-item label="供应商-商品编码SKU" prop="supplierProductSku">
        <el-input v-model="formData.supplierProductSku" placeholder="请输入供应商-商品编码SKU" />
      </el-form-item>
      <el-form-item label="外部订单编号" prop="sourceId">
        <el-input v-model="formData.sourceId" placeholder="请输入外部订单编号" />
      </el-form-item>
      <el-form-item label="分享ID" prop="shareId">
        <el-input v-model="formData.shareId" placeholder="请输入分享ID" />
      </el-form-item>
      <el-form-item label="用户ID" prop="userId">
        <el-input v-model="formData.userId" placeholder="请输入用户ID" />
      </el-form-item>
      <el-form-item label="产品SKU" prop="productSku">
        <el-input v-model="formData.productSku" placeholder="请输入产品SKU" />
      </el-form-item>
      <el-form-item label="外部SKU" prop="sourceSku">
        <el-input v-model="formData.sourceSku" placeholder="请输入外部SKU" />
      </el-form-item>
      <el-form-item label="计划手机号" prop="planMobile">
        <el-input v-model="formData.planMobile" placeholder="请输入计划手机号" />
      </el-form-item>
      <el-form-item label="生产手机号" prop="planMobileProduced">
        <el-input v-model="formData.planMobileProduced" placeholder="请输入生产手机号" />
      </el-form-item>
      <el-form-item label="证件姓名" prop="idCardName">
        <el-input v-model="formData.idCardName" placeholder="请输入证件姓名" />
      </el-form-item>
      <el-form-item label="证件号码" prop="idCardNum">
        <el-input v-model="formData.idCardNum" placeholder="请输入证件号码" />
      </el-form-item>
      <el-form-item label="地址省编码" prop="addressProvinceCode">
        <el-input v-model="formData.addressProvinceCode" placeholder="请输入地址省编码" />
      </el-form-item>
      <el-form-item label="地址市编码" prop="addressCityCode">
        <el-input v-model="formData.addressCityCode" placeholder="请输入地址市编码" />
      </el-form-item>
      <el-form-item label="地址区编码" prop="addressDistrictCode">
        <el-input v-model="formData.addressDistrictCode" placeholder="请输入地址区编码" />
      </el-form-item>
      <el-form-item label="地址省" prop="addressProvince">
        <el-input v-model="formData.addressProvince" placeholder="请输入地址省" />
      </el-form-item>
      <el-form-item label="地址市" prop="addressCity">
        <el-input v-model="formData.addressCity" placeholder="请输入地址市" />
      </el-form-item>
      <el-form-item label="地址区" prop="addressDistrict">
        <el-input v-model="formData.addressDistrict" placeholder="请输入地址区" />
      </el-form-item>
      <el-form-item label="详细地址" prop="address">
        <el-input v-model="formData.address" placeholder="请输入详细地址" />
      </el-form-item>
      <el-form-item label="收件人电话" prop="addressMobile">
        <el-input v-model="formData.addressMobile" placeholder="请输入收件人电话" />
      </el-form-item>
      <el-form-item label="收件人姓名" prop="addressName">
        <el-input v-model="formData.addressName" placeholder="请输入收件人姓名" />
      </el-form-item>
      <el-form-item label="物流公司ID" prop="trackingCompanyId">
        <el-input v-model="formData.trackingCompanyId" placeholder="请输入物流公司ID" />
      </el-form-item>
      <el-form-item label="物流单号" prop="trackingNumber">
        <el-input v-model="formData.trackingNumber" placeholder="请输入物流单号" />
      </el-form-item>
      <el-form-item label="买家备注" prop="buyerMemo">
        <el-input v-model="formData.buyerMemo" placeholder="请输入买家备注" />
      </el-form-item>
      <el-form-item label="卖家备注" prop="sellerMemo">
        <el-input v-model="formData.sellerMemo" placeholder="请输入卖家备注" />
      </el-form-item>
      <el-form-item label="生产备注" prop="producerMemo">
        <el-input v-model="formData.producerMemo" placeholder="请输入生产备注" />
      </el-form-item>
      <el-form-item label="订单状态码" prop="status">
        <el-radio-group v-model="formData.status">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="标志" prop="flag">
        <el-input v-model="formData.flag" placeholder="请输入标志" />
      </el-form-item>
      <el-form-item label="预警区域" prop="warnArea">
        <el-input v-model="formData.warnArea" placeholder="请输入预警区域" />
      </el-form-item>
      <el-form-item label="原因" prop="reason">
        <el-input v-model="formData.reason" placeholder="请输入原因" />
      </el-form-item>
      <el-form-item label="订单来源" prop="source">
        <el-input v-model="formData.source" placeholder="请输入订单来源" />
      </el-form-item>
      <el-form-item label="用户下单时间" prop="orderedAt">
        <el-date-picker
          v-model="formData.orderedAt"
          type="date"
          value-format="x"
          placeholder="选择用户下单时间"
        />
      </el-form-item>
      <el-form-item label="生产时间" prop="producedAt">
        <el-date-picker
          v-model="formData.producedAt"
          type="date"
          value-format="x"
          placeholder="选择生产时间"
        />
      </el-form-item>
      <el-form-item label="发货时间" prop="deliveredAt">
        <el-date-picker
          v-model="formData.deliveredAt"
          type="date"
          value-format="x"
          placeholder="选择发货时间"
        />
      </el-form-item>
      <el-form-item label="激活时间" prop="activatedAt">
        <el-date-picker
          v-model="formData.activatedAt"
          type="date"
          value-format="x"
          placeholder="选择激活时间"
        />
      </el-form-item>
      <el-form-item label="充值时间" prop="rechargedAt">
        <el-date-picker
          v-model="formData.rechargedAt"
          type="date"
          value-format="x"
          placeholder="选择充值时间"
        />
      </el-form-item>
      <el-form-item label="卖家备注" prop="memo">
        <el-input v-model="formData.memo" placeholder="请输入卖家备注" />
      </el-form-item>
      <el-form-item label="数量" prop="amount">
        <el-input v-model="formData.amount" placeholder="请输入数量" />
      </el-form-item>
      <el-form-item label="状态变更时间" prop="statusUpdatedAt">
        <el-date-picker
          v-model="formData.statusUpdatedAt"
          type="date"
          value-format="x"
          placeholder="选择状态变更时间"
        />
      </el-form-item>
      <el-form-item label="退款状态" prop="refundStatus">
        <el-input v-model="formData.refundStatus" placeholder="请输入退款状态" />
      </el-form-item>
      <el-form-item label="激活状态" prop="activeStatus">
        <el-input v-model="formData.activeStatus" placeholder="请输入激活状态" />
      </el-form-item>
      <el-form-item label="ICCID" prop="iccid">
        <el-input v-model="formData.iccid" placeholder="请输入ICCID" />
      </el-form-item>
      <el-form-item label="真实外部订单编号" prop="realSourceId">
        <el-input v-model="formData.realSourceId" placeholder="请输入真实外部订单编号" />
      </el-form-item>
      <el-form-item label="图片大小" prop="picSize">
        <el-input v-model="formData.picSize" placeholder="请输入图片大小" />
      </el-form-item>
      <el-form-item label="归属地省" prop="regionP">
        <el-input v-model="formData.regionP" placeholder="请输入归属地省" />
      </el-form-item>
      <el-form-item label="归属地市" prop="regionC">
        <el-input v-model="formData.regionC" placeholder="请输入归属地市" />
      </el-form-item>
      <el-form-item label="分销商名称" prop="merchantName">
        <el-input v-model="formData.merchantName" placeholder="请输入分销商名称" />
      </el-form-item>
      <el-form-item label="上游状态" prop="upStatus">
        <el-radio-group v-model="formData.upStatus">
          <el-radio value="1">请选择字典生成</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="上游订单号" prop="upstreamOrderId">
        <el-input v-model="formData.upstreamOrderId" placeholder="请输入上游订单号" />
      </el-form-item>
      <el-form-item label="镇/乡" prop="town">
        <el-input v-model="formData.town" placeholder="请输入镇/乡" />
      </el-form-item>
      <el-form-item label="物流公司名称" prop="trackingCompany">
        <el-input v-model="formData.trackingCompany" placeholder="请输入物流公司名称" />
      </el-form-item>
      <el-form-item label="订单状态名称" prop="statusName">
        <el-input v-model="formData.statusName" placeholder="请输入订单状态名称" />
      </el-form-item>
      <el-form-item label="加密收货电话" prop="encryptAddressMobile">
        <el-input v-model="formData.encryptAddressMobile" placeholder="请输入加密收货电话" />
      </el-form-item>
      <el-form-item label="加密收货人姓名" prop="encryptAddressName">
        <el-input v-model="formData.encryptAddressName" placeholder="请输入加密收货人姓名" />
      </el-form-item>
      <el-form-item label="加密证件姓名" prop="encryptIdCardName">
        <el-input v-model="formData.encryptIdCardName" placeholder="请输入加密证件姓名" />
      </el-form-item>
      <el-form-item label="加密证件号码" prop="encryptIdCardNum">
        <el-input v-model="formData.encryptIdCardNum" placeholder="请输入加密证件号码" />
      </el-form-item>
      <el-form-item label="加密详细地址" prop="encryptAddress">
        <el-input v-model="formData.encryptAddress" placeholder="请输入加密详细地址" />
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="submitForm" type="primary" :disabled="formLoading">确 定</el-button>
      <el-button @click="dialogVisible = false">取 消</el-button>
    </template>
  </Dialog>
</template>
<script setup lang="ts">
import { OrdersApi, OrdersVO } from '@/api/haoka/orders'

/** 订单 表单 */
defineOptions({ name: 'OrdersForm' })

const { t } = useI18n() // 国际化
const message = useMessage() // 消息弹窗

const dialogVisible = ref(false) // 弹窗的是否展示
const dialogTitle = ref('') // 弹窗的标题
const formLoading = ref(false) // 表单的加载中：1）修改时的数据加载；2）提交的按钮禁用
const formType = ref('') // 表单的类型：create - 新增；update - 修改
const formData = ref({
  id: undefined,
  producerId: undefined,
  productId: undefined,
  supplierProductName: undefined,
  supplierProductSku: undefined,
  sourceId: undefined,
  shareId: undefined,
  userId: undefined,
  productSku: undefined,
  sourceSku: undefined,
  planMobile: undefined,
  planMobileProduced: undefined,
  idCardName: undefined,
  idCardNum: undefined,
  addressProvinceCode: undefined,
  addressCityCode: undefined,
  addressDistrictCode: undefined,
  addressProvince: undefined,
  addressCity: undefined,
  addressDistrict: undefined,
  address: undefined,
  addressMobile: undefined,
  addressName: undefined,
  trackingCompanyId: undefined,
  trackingNumber: undefined,
  buyerMemo: undefined,
  sellerMemo: undefined,
  producerMemo: undefined,
  status: undefined,
  flag: undefined,
  warnArea: undefined,
  reason: undefined,
  source: undefined,
  orderedAt: undefined,
  producedAt: undefined,
  deliveredAt: undefined,
  activatedAt: undefined,
  rechargedAt: undefined,
  memo: undefined,
  amount: undefined,
  statusUpdatedAt: undefined,
  refundStatus: undefined,
  activeStatus: undefined,
  iccid: undefined,
  realSourceId: undefined,
  picSize: undefined,
  regionP: undefined,
  regionC: undefined,
  merchantName: undefined,
  upStatus: undefined,
  upstreamOrderId: undefined,
  town: undefined,
  trackingCompany: undefined,
  statusName: undefined,
  encryptAddressMobile: undefined,
  encryptAddressName: undefined,
  encryptIdCardName: undefined,
  encryptIdCardNum: undefined,
  encryptAddress: undefined,
})
const formRules = reactive({
})
const formRef = ref() // 表单 Ref

/** 打开弹窗 */
const open = async (type: string, id?: number) => {
  dialogVisible.value = true
  dialogTitle.value = t('action.' + type)
  formType.value = type
  resetForm()
  // 修改时，设置数据
  if (id) {
    formLoading.value = true
    try {
      formData.value = await OrdersApi.getOrders(id)
    } finally {
      formLoading.value = false
    }
  }
}
defineExpose({ open }) // 提供 open 方法，用于打开弹窗

/** 提交表单 */
const emit = defineEmits(['success']) // 定义 success 事件，用于操作成功后的回调
const submitForm = async () => {
  // 校验表单
  await formRef.value.validate()
  // 提交请求
  formLoading.value = true
  try {
    const data = formData.value as unknown as OrdersVO
    if (formType.value === 'create') {
      await OrdersApi.createOrders(data)
      message.success(t('common.createSuccess'))
    } else {
      await OrdersApi.updateOrders(data)
      message.success(t('common.updateSuccess'))
    }
    dialogVisible.value = false
    // 发送操作成功的事件
    emit('success')
  } finally {
    formLoading.value = false
  }
}

/** 重置表单 */
const resetForm = () => {
  formData.value = {
    id: undefined,
    producerId: undefined,
    productId: undefined,
    supplierProductName: undefined,
    supplierProductSku: undefined,
    sourceId: undefined,
    shareId: undefined,
    userId: undefined,
    productSku: undefined,
    sourceSku: undefined,
    planMobile: undefined,
    planMobileProduced: undefined,
    idCardName: undefined,
    idCardNum: undefined,
    addressProvinceCode: undefined,
    addressCityCode: undefined,
    addressDistrictCode: undefined,
    addressProvince: undefined,
    addressCity: undefined,
    addressDistrict: undefined,
    address: undefined,
    addressMobile: undefined,
    addressName: undefined,
    trackingCompanyId: undefined,
    trackingNumber: undefined,
    buyerMemo: undefined,
    sellerMemo: undefined,
    producerMemo: undefined,
    status: undefined,
    flag: undefined,
    warnArea: undefined,
    reason: undefined,
    source: undefined,
    orderedAt: undefined,
    producedAt: undefined,
    deliveredAt: undefined,
    activatedAt: undefined,
    rechargedAt: undefined,
    memo: undefined,
    amount: undefined,
    statusUpdatedAt: undefined,
    refundStatus: undefined,
    activeStatus: undefined,
    iccid: undefined,
    realSourceId: undefined,
    picSize: undefined,
    regionP: undefined,
    regionC: undefined,
    merchantName: undefined,
    upStatus: undefined,
    upstreamOrderId: undefined,
    town: undefined,
    trackingCompany: undefined,
    statusName: undefined,
    encryptAddressMobile: undefined,
    encryptAddressName: undefined,
    encryptIdCardName: undefined,
    encryptIdCardNum: undefined,
    encryptAddress: undefined,
  }
  formRef.value?.resetFields()
}
</script>