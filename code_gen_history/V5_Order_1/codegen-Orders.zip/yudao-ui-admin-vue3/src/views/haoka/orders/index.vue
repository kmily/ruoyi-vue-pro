<template>
  <ContentWrap>
    <!-- 搜索工作栏 -->
    <el-form
      class="-mb-15px"
      :model="queryParams"
      ref="queryFormRef"
      :inline="true"
      label-width="68px"
    >
      <el-form-item label="供应商-商品名称" prop="supplierProductName">
        <el-input
          v-model="queryParams.supplierProductName"
          placeholder="请输入供应商-商品名称"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="供应商-商品编码SKU" prop="supplierProductSku">
        <el-input
          v-model="queryParams.supplierProductSku"
          placeholder="请输入供应商-商品编码SKU"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="外部订单编号" prop="sourceId">
        <el-input
          v-model="queryParams.sourceId"
          placeholder="请输入外部订单编号"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="产品SKU" prop="productSku">
        <el-input
          v-model="queryParams.productSku"
          placeholder="请输入产品SKU"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="外部SKU" prop="sourceSku">
        <el-input
          v-model="queryParams.sourceSku"
          placeholder="请输入外部SKU"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="证件号码" prop="idCardNum">
        <el-input
          v-model="queryParams.idCardNum"
          placeholder="请输入证件号码"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="收件人电话" prop="addressMobile">
        <el-input
          v-model="queryParams.addressMobile"
          placeholder="请输入收件人电话"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="物流单号" prop="trackingNumber">
        <el-input
          v-model="queryParams.trackingNumber"
          placeholder="请输入物流单号"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="订单状态码" prop="status">
        <el-select
          v-model="queryParams.status"
          placeholder="请选择订单状态码"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="标志" prop="flag">
        <el-input
          v-model="queryParams.flag"
          placeholder="请输入标志"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="订单来源" prop="source">
        <el-input
          v-model="queryParams.source"
          placeholder="请输入订单来源"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="用户下单时间" prop="orderedAt">
        <el-date-picker
          v-model="queryParams.orderedAt"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择用户下单时间"
          clearable
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="生产时间" prop="producedAt">
        <el-date-picker
          v-model="queryParams.producedAt"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择生产时间"
          clearable
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="发货时间" prop="deliveredAt">
        <el-date-picker
          v-model="queryParams.deliveredAt"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择发货时间"
          clearable
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="激活时间" prop="activatedAt">
        <el-date-picker
          v-model="queryParams.activatedAt"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择激活时间"
          clearable
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="充值时间" prop="rechargedAt">
        <el-date-picker
          v-model="queryParams.rechargedAt"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择充值时间"
          clearable
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="状态变更时间" prop="statusUpdatedAt">
        <el-date-picker
          v-model="queryParams.statusUpdatedAt"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择状态变更时间"
          clearable
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="退款状态" prop="refundStatus">
        <el-input
          v-model="queryParams.refundStatus"
          placeholder="请输入退款状态"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="激活状态" prop="activeStatus">
        <el-input
          v-model="queryParams.activeStatus"
          placeholder="请输入激活状态"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="ICCID" prop="iccid">
        <el-input
          v-model="queryParams.iccid"
          placeholder="请输入ICCID"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="真实外部订单编号" prop="realSourceId">
        <el-input
          v-model="queryParams.realSourceId"
          placeholder="请输入真实外部订单编号"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="分销商名称" prop="merchantName">
        <el-input
          v-model="queryParams.merchantName"
          placeholder="请输入分销商名称"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="上游状态" prop="upStatus">
        <el-select
          v-model="queryParams.upStatus"
          placeholder="请选择上游状态"
          clearable
          class="!w-240px"
        >
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="上游订单号" prop="upstreamOrderId">
        <el-input
          v-model="queryParams.upstreamOrderId"
          placeholder="请输入上游订单号"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item label="订单状态名称" prop="statusName">
        <el-input
          v-model="queryParams.statusName"
          placeholder="请输入订单状态名称"
          clearable
          @keyup.enter="handleQuery"
          class="!w-240px"
        />
      </el-form-item>
      <el-form-item>
        <el-button @click="handleQuery"><Icon icon="ep:search" class="mr-5px" /> 搜索</el-button>
        <el-button @click="resetQuery"><Icon icon="ep:refresh" class="mr-5px" /> 重置</el-button>
        <el-button
          type="primary"
          plain
          @click="openForm('create')"
          v-hasPermi="['haoka:orders:create']"
        >
          <Icon icon="ep:plus" class="mr-5px" /> 新增
        </el-button>
        <el-button
          type="success"
          plain
          @click="handleExport"
          :loading="exportLoading"
          v-hasPermi="['haoka:orders:export']"
        >
          <Icon icon="ep:download" class="mr-5px" /> 导出
        </el-button>
      </el-form-item>
    </el-form>
  </ContentWrap>

  <!-- 列表 -->
  <ContentWrap>
    <el-table v-loading="loading" :data="list" :stripe="true" :show-overflow-tooltip="true">
      <el-table-column label="订单ID" align="center" prop="id" />
      <el-table-column label="生产商ID" align="center" prop="producerId" />
      <el-table-column label="产品ID" align="center" prop="productId" />
      <el-table-column label="供应商-商品名称" align="center" prop="supplierProductName" />
      <el-table-column label="供应商-商品编码SKU" align="center" prop="supplierProductSku" />
      <el-table-column label="外部订单编号" align="center" prop="sourceId" />
      <el-table-column label="分享ID" align="center" prop="shareId" />
      <el-table-column label="用户ID" align="center" prop="userId" />
      <el-table-column label="产品SKU" align="center" prop="productSku" />
      <el-table-column label="外部SKU" align="center" prop="sourceSku" />
      <el-table-column label="计划手机号" align="center" prop="planMobile" />
      <el-table-column label="生产手机号" align="center" prop="planMobileProduced" />
      <el-table-column label="证件姓名" align="center" prop="idCardName" />
      <el-table-column label="证件号码" align="center" prop="idCardNum" />
      <el-table-column label="地址省编码" align="center" prop="addressProvinceCode" />
      <el-table-column label="地址市编码" align="center" prop="addressCityCode" />
      <el-table-column label="地址区编码" align="center" prop="addressDistrictCode" />
      <el-table-column label="地址省" align="center" prop="addressProvince" />
      <el-table-column label="地址市" align="center" prop="addressCity" />
      <el-table-column label="地址区" align="center" prop="addressDistrict" />
      <el-table-column label="详细地址" align="center" prop="address" />
      <el-table-column label="收件人电话" align="center" prop="addressMobile" />
      <el-table-column label="收件人姓名" align="center" prop="addressName" />
      <el-table-column label="物流公司ID" align="center" prop="trackingCompanyId" />
      <el-table-column label="物流单号" align="center" prop="trackingNumber" />
      <el-table-column label="买家备注" align="center" prop="buyerMemo" />
      <el-table-column label="卖家备注" align="center" prop="sellerMemo" />
      <el-table-column label="生产备注" align="center" prop="producerMemo" />
      <el-table-column label="订单状态码" align="center" prop="status" />
      <el-table-column label="标志" align="center" prop="flag" />
      <el-table-column label="预警区域" align="center" prop="warnArea" />
      <el-table-column label="原因" align="center" prop="reason" />
      <el-table-column label="订单来源" align="center" prop="source" />
      <el-table-column
        label="用户下单时间"
        align="center"
        prop="orderedAt"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="生产时间"
        align="center"
        prop="producedAt"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="发货时间"
        align="center"
        prop="deliveredAt"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="激活时间"
        align="center"
        prop="activatedAt"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column
        label="充值时间"
        align="center"
        prop="rechargedAt"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="卖家备注" align="center" prop="memo" />
      <el-table-column label="数量" align="center" prop="amount" />
      <el-table-column
        label="状态变更时间"
        align="center"
        prop="statusUpdatedAt"
        :formatter="dateFormatter"
        width="180px"
      />
      <el-table-column label="退款状态" align="center" prop="refundStatus" />
      <el-table-column label="激活状态" align="center" prop="activeStatus" />
      <el-table-column label="ICCID" align="center" prop="iccid" />
      <el-table-column label="真实外部订单编号" align="center" prop="realSourceId" />
      <el-table-column label="图片大小" align="center" prop="picSize" />
      <el-table-column label="归属地省" align="center" prop="regionP" />
      <el-table-column label="归属地市" align="center" prop="regionC" />
      <el-table-column label="分销商名称" align="center" prop="merchantName" />
      <el-table-column label="上游状态" align="center" prop="upStatus" />
      <el-table-column label="上游订单号" align="center" prop="upstreamOrderId" />
      <el-table-column label="镇/乡" align="center" prop="town" />
      <el-table-column label="物流公司名称" align="center" prop="trackingCompany" />
      <el-table-column label="订单状态名称" align="center" prop="statusName" />
      <el-table-column label="加密收货电话" align="center" prop="encryptAddressMobile" />
      <el-table-column label="加密收货人姓名" align="center" prop="encryptAddressName" />
      <el-table-column label="加密证件姓名" align="center" prop="encryptIdCardName" />
      <el-table-column label="加密证件号码" align="center" prop="encryptIdCardNum" />
      <el-table-column label="加密详细地址" align="center" prop="encryptAddress" />
      <el-table-column label="操作" align="center" min-width="120px">
        <template #default="scope">
          <el-button
            link
            type="primary"
            @click="openForm('update', scope.row.id)"
            v-hasPermi="['haoka:orders:update']"
          >
            编辑
          </el-button>
          <el-button
            link
            type="danger"
            @click="handleDelete(scope.row.id)"
            v-hasPermi="['haoka:orders:delete']"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <Pagination
      :total="total"
      v-model:page="queryParams.pageNo"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </ContentWrap>

  <!-- 表单弹窗：添加/修改 -->
  <OrdersForm ref="formRef" @success="getList" />
</template>

<script setup lang="ts">
import { dateFormatter } from '@/utils/formatTime'
import download from '@/utils/download'
import { OrdersApi, OrdersVO } from '@/api/haoka/orders'
import OrdersForm from './OrdersForm.vue'

/** 订单 列表 */
defineOptions({ name: 'Orders' })

const message = useMessage() // 消息弹窗
const { t } = useI18n() // 国际化

const loading = ref(true) // 列表的加载中
const list = ref<OrdersVO[]>([]) // 列表的数据
const total = ref(0) // 列表的总页数
const queryParams = reactive({
  pageNo: 1,
  pageSize: 10,
  supplierProductName: undefined,
  supplierProductSku: undefined,
  sourceId: undefined,
  productSku: undefined,
  sourceSku: undefined,
  idCardNum: undefined,
  addressMobile: undefined,
  trackingNumber: undefined,
  status: undefined,
  flag: undefined,
  source: undefined,
  orderedAt: undefined,
  orderedAt: [],
  producedAt: undefined,
  producedAt: [],
  deliveredAt: undefined,
  deliveredAt: [],
  activatedAt: undefined,
  activatedAt: [],
  rechargedAt: undefined,
  rechargedAt: [],
  statusUpdatedAt: undefined,
  statusUpdatedAt: [],
  refundStatus: undefined,
  activeStatus: undefined,
  iccid: undefined,
  realSourceId: undefined,
  merchantName: undefined,
  upStatus: undefined,
  upstreamOrderId: undefined,
  statusName: undefined,
})
const queryFormRef = ref() // 搜索的表单
const exportLoading = ref(false) // 导出的加载中

/** 查询列表 */
const getList = async () => {
  loading.value = true
  try {
    const data = await OrdersApi.getOrdersPage(queryParams)
    list.value = data.list
    total.value = data.total
  } finally {
    loading.value = false
  }
}

/** 搜索按钮操作 */
const handleQuery = () => {
  queryParams.pageNo = 1
  getList()
}

/** 重置按钮操作 */
const resetQuery = () => {
  queryFormRef.value.resetFields()
  handleQuery()
}

/** 添加/修改操作 */
const formRef = ref()
const openForm = (type: string, id?: number) => {
  formRef.value.open(type, id)
}

/** 删除按钮操作 */
const handleDelete = async (id: number) => {
  try {
    // 删除的二次确认
    await message.delConfirm()
    // 发起删除
    await OrdersApi.deleteOrders(id)
    message.success(t('common.delSuccess'))
    // 刷新列表
    await getList()
  } catch {}
}

/** 导出按钮操作 */
const handleExport = async () => {
  try {
    // 导出的二次确认
    await message.exportConfirm()
    // 发起导出
    exportLoading.value = true
    const data = await OrdersApi.exportOrders(queryParams)
    download.excel(data, '订单.xls')
  } catch {
  } finally {
    exportLoading.value = false
  }
}

/** 初始化 **/
onMounted(() => {
  getList()
})
</script>